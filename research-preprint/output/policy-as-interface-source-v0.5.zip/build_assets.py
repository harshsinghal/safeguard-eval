"""Regenerate manuscript tables and vector figures from immutable public evidence.

Run from any directory. Requires matplotlib; performs no network or model calls.
"""
from pathlib import Path
import csv
import hashlib
import json
import shutil
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

HERE = Path(__file__).resolve().parent
REPO = HERE.parent
OUT = HERE / 'generated'
FIG = HERE / 'figures'
for p in [OUT, FIG, HERE / 'policies']:
    p.mkdir(exist_ok=True)
SOURCES = {}

def read(path):
    p = REPO / path
    SOURCES[path] = hashlib.sha256(p.read_bytes()).hexdigest()
    return json.loads(p.read_text())

w = read('published_runs/2026-10-24-wildguard/analysis.json')
q = read('published_runs/2026-10-25-qwen/analysis.json')
f = read('published_runs/2026-10-25-frontier-pilot/analysis.json')
ws = read('published_runs/2026-10-24-wildguard/selection.json')
qs = read('published_runs/2026-10-25-qwen/selection.json')
wr = read('evals/wildguard/revisions.json')
qr = read('docs/qwen-policy/model-revisions.json')

NAMES = {'policylm':'PolicyLM-1.7B', 'shieldstral':'Shieldstral-3B',
         'cope':'CoPE-B-A4B', 'safeguard':'GPT-OSS Safeguard-20B', 'wildguard':'WildGuard-7B'}
ORDER = ['policylm','shieldstral','cope','safeguard','wildguard']
QORDER = ['Qwen/Qwen3.5-'+x for x in ['2B','4B','9B','27B','35B-A3B']]
def name(model):
    return NAMES.get(model, model.replace('Qwen/',''))
def fmt(v):
    return f'{100*v:.2f}'
def tex(s):
    return str(s).replace('\\',r'\textbackslash{}').replace('_',r'\_').replace('&',r'\&').replace('%',r'\%').replace('#',r'\#')
def row(*xs):
    return ' & '.join(map(str,xs))+r' \\'+'\n'
def rowsfile(path, lines):
    (OUT/path).write_text(''.join(lines))

entries = []
for m in ORDER:
    es = [e for e in w['entries'] if e['adapter']==m]
    selected = next(e for e in es if 'individual' in e['roles'] or 'baseline' in e['roles'])
    initial = next((e for e in es if 'initial' in e['roles']),selected)
    shared = next((e for e in es if 'shared' in e['roles']),None)
    entries.append(dict(model=m, family='Specialist',initial=initial,shared=shared,selected=selected))
for m in QORDER:
    es = [e for e in q['entries'] if e['model']==m and e['split']=='test']
    entries.append(dict(model=m,family='Qwen',
        initial=next(e for e in es if 'initial' in e['roles']),
        shared=next(e for e in es if 'shared' in e['roles']),
        selected=next(e for e in es if 'selected' in e['roles'])))

main, detail, data = [], [], []
for x in entries:
    m=x['selected']['metrics']; assert m['n']==1699
    if x['model']==QORDER[0]: main.append(r'\midrule'+'\n'); detail.append(r'\midrule'+'\n')
    main.append(row(tex(name(x['model'])),fmt(x['initial']['metrics']['accuracy']),
        fmt(x['shared']['metrics']['accuracy']) if x['shared'] else '--',fmt(m['accuracy']),fmt(m['harmful_f1']),m['errors']))
    detail.append(row(tex(name(x['model'])),fmt(m['harmful_recall']),fmt(m['benign_false_positive_rate']),
        fmt(m['macro_f1']),fmt(m['official_harmful_f1']),m['errors']))
    data.append(dict(model=x['model'],run=x['selected']['run'],policy=x['selected']['policy_id'],
        initial_accuracy=x['initial']['metrics']['accuracy'],shared_accuracy=x['shared']['metrics']['accuracy'] if x['shared'] else None,
        **{k:v for k,v in m.items() if k not in ['slices','confusion']}))
rowsfile('main-results.tex',main);rowsfile('additional-metrics.tex',detail)
with (OUT/'results.csv').open('w') as h:
    writer=csv.DictWriter(h,fieldnames=data[0].keys());writer.writeheader();writer.writerows(data)

selection=[]
for model in ORDER[:-1]:
    r=next(x for x in ws['records'] if x['id']==ws['individual'][model]);s=r['scores'][model]
    selection.append(row(tex(name(model)),tex(r['id'].split('-')[1]),r['words'],fmt(s['fit']['accuracy']),fmt(s['validation']['accuracy'])))
for model in QORDER:
    r=next(x for x in qs['records'] if x['model']==model and x['policy_id']==qs['selected'][model]);s=r['scores']
    pid=r['policy_id']; short=pid.split('-')[1] if pid.startswith('wg-') else next(a for a in pid.split('-') if a in ['p3','p4'])
    selection.append(row(tex(name(model)),short,r['words'],fmt(s['fit']['accuracy']),fmt(s['validation']['accuracy'])))
rowsfile('selection.tex',selection)

pairs=[x for x in q['paired_comparisons'] if x['role']=='selected']
pairrows=[]
for x in pairs:
    d=x['qwen_minus_policy'];lo,hi=d['ci95']
    pairrows.append(row(tex(name(x['model'])),tex(name(x['comparator'])),f'{100*d["delta"]:+.2f}',
        f'[{100*lo:+.2f}, {100*hi:+.2f}]',f'{d["a_correct_b_wrong"]}/{d["a_wrong_b_correct"]}'))
rowsfile('pairs.tex',pairrows)

frontier_names={'astra':'GPT-6 Astra','opus':'Claude Opus 5.5','deepseek':'DeepSeek V4.1 Flash','kimi':'Kimi K3.1 Pro'}
front=[]
for key,e in f['conditions'].items():
    family,mode=key.split('-');effort=('low' if family in ['astra','opus'] else 'off') if mode=='lower' else 'high'
    c=e['descriptive_fitting_metrics']['confusion'];correct=c['ALLOW']['ALLOW']+c['BLOCK']['BLOCK']
    front.append(row(frontier_names[family],effort,f'{e["valid"]}/32',f'{correct}/32',f'{c["BLOCK"]["BLOCK"]}/3',
                     e['error_types'].get('ContentFiltered',0),e['error_types'].get('InvalidClassification',0)+e['error_types'].get('RateLimited',0)))
rowsfile('frontier.tex',front)

# Copy all authored policy texts and record provenance; source prompts are never used.
policy_index=[]
for folder in ['evals/wildguard/policies','evals/qwen_policy/policies','published_runs/2026-10-25-policy-transfer/policies']:
    for p in sorted((REPO/folder).glob('*.json')):
        d=read(str(p.relative_to(REPO)))
        target=HERE/'policies'/(d['id']+'.json'); shutil.copyfile(p,target)
        policy_index.append({'id':d['id'],'source':str(p.relative_to(REPO)),'sha256':SOURCES[str(p.relative_to(REPO))]})
(OUT/'policy-index.json').write_text(json.dumps(policy_index,indent=2)+'\n')
rev=[]
for k,v in {**{k:v for k,v in wr.items() if k!='dataset'},**qr}.items():
    rev.append(row(r'\path{'+k+'}',r'\texttt{'+v['revision']+'}'))
rowsfile('revisions.tex',rev)
p0=json.loads((HERE/'policies/wg-p0-taxonomy.json').read_text())
rowsfile('initial-policy.tex',[r'\paragraph{'+tex(k.title())+'} '+tex(p0[k])+'\n\n' for k in ['purpose','block','allow','review','precedence']])

plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,
    'axes.spines.right':False,'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none',
    'axes.labelcolor':'#243447','text.color':'#243447','xtick.color':'#4b5563','ytick.color':'#243447'})
BLUE='#146a88'; TEAL='#16806a'; ORANGE='#c46a25'; GRAY='#a6adb5'; LIGHT='#edf4f6'; RED='#b24a48'
def save(fig,name):
    fig.savefig(FIG/(name+'.pdf'),bbox_inches='tight',metadata={'Creator':'build_assets.py; archived experimental results'})
    fig.savefig(FIG/(name+'.svg'),bbox_inches='tight')
    fig.savefig(FIG/(name+'.png'),dpi=180,bbox_inches='tight');plt.close(fig)

gains=[x for x in entries if x['model']!='wildguard']
fig,ax=plt.subplots(figsize=(8,4.5))
for i,x in enumerate(gains):
    d=x['selected']['vs_initial'];lo,hi=d['ci95'];val=d['delta']*100
    ax.errorbar(val,i,xerr=[[val-100*lo],[100*hi-val]],fmt='o',color=BLUE if x['family']=='Specialist' else TEAL,capsize=3,markersize=6)
    ax.text(1.02,i,f'{val:+.2f}',transform=ax.get_yaxis_transform(),va='center',ha='left',fontsize=10)
ax.set_yticks(range(len(gains)),[name(x['model']) for x in gains]);ax.invert_yaxis()
ax.axvline(0,color='#6b7280',lw=1,ls='--');ax.axhline(3.5,color='#d9dee3',lw=1)
ax.set_xlim(-1.6,4.9);ax.set_xlabel('Selected minus initial accuracy (percentage points)')
ax.set_title('Policy selection helped some deployments, but not all',loc='left',fontweight='bold',pad=14)
ax.grid(axis='x',alpha=.18);ax.set_axisbelow(True)
fig.tight_layout();save(fig,'policy-gains')

fig,ax=plt.subplots(figsize=(8,3.8))
for i,x in enumerate(pairs):
    d=x['qwen_minus_policy'];lo,hi=d['ci95'];val=d['delta']*100
    ax.errorbar(val,i,xerr=[[val-100*lo],[100*hi-val]],fmt='o',color=BLUE,capsize=3,markersize=6)
ax.set_yticks(range(len(pairs)),[name(x['model']).replace('Qwen3.5-','Qwen ')+' vs '+name(x['comparator']).replace('GPT-OSS ','') for x in pairs])
ax.invert_yaxis();ax.axvline(0,color='#6b7280',ls='--',lw=1);ax.set_xlim(-6.2,3.8)
ax.set_xlabel('Qwen minus specialist accuracy (percentage points)')
ax.set_title('Nearby-size comparisons have mixed outcomes',loc='left',fontweight='bold',pad=14)
ax.grid(axis='x',alpha=.18);ax.set_axisbelow(True)
fig.tight_layout();save(fig,'nearby-size')

fig,(a,b)=plt.subplots(1,2,figsize=(9.5,4.1),gridspec_kw={'width_ratios':[1.3,1]})
labels=[]
for i,(key,e) in enumerate(f['conditions'].items()):
    fam,mode=key.split('-');effort=('low' if fam in ['astra','opus'] else 'off') if mode=='lower' else 'high'
    labels.append(frontier_names[fam].replace(' V4.1 Flash','')+' / '+effort)
    c=e['descriptive_fitting_metrics']['confusion'];correct=c['ALLOW']['ALLOW']+c['BLOCK']['BLOCK']
    vals=[correct,e['valid']-correct,e['error_types'].get('ContentFiltered',0),32-e['valid']-e['error_types'].get('ContentFiltered',0)]
    left=0
    for j,(v,color) in enumerate(zip(vals,[TEAL,GRAY,ORANGE,RED])):
        if v:a.barh(i,v,left=left,color=color,height=.66)
        left+=v
    left=0
    for v,color in zip([c['BLOCK']['BLOCK'],c['BLOCK']['ALLOW'],c['BLOCK']['ERROR']],[TEAL,GRAY,ORANGE]):
        if v:
            b.barh(i,v,left=left,color=color,height=.66);b.text(left+v/2,i,str(v),ha='center',va='center',fontsize=9,color='white' if color!=GRAY else '#243447')
        left+=v
a.set_yticks(range(8),labels);b.set_yticks(range(8),[])
for ax in [a,b]:ax.invert_yaxis();ax.grid(axis='x',alpha=.15);ax.set_axisbelow(True)
a.set_xlim(0,32);a.set_xticks([0,8,16,24,32]);a.set_xlabel('All 32 fitting prompts')
b.set_xlim(0,3);b.set_xticks([0,1,2,3]);b.set_xlabel('Only 3 harmful-labeled prompts')
a.set_title('Overall outcomes',loc='left',fontweight='bold');b.set_title('Harmful subset',loc='left',fontweight='bold')
from matplotlib.patches import Patch
fig.legend(handles=[Patch(color=c,label=l) for c,l in zip([TEAL,GRAY,ORANGE,RED],['Correct label','Incorrect label','Content filter','Format / rate limit'])],loc='lower center',ncol=4,frameon=False,fontsize=9,bbox_to_anchor=(.5,-.045))
fig.tight_layout(w_pad=2);save(fig,'api-pilot')

def box(ax,x,y,w,h,title,body,color=LIGHT):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.012,rounding_size=0.02',fc=color,ec='#b7c9d2',lw=1))
    ax.text(x+w/2,y+h*.72,title,ha='center',va='center',fontweight='bold',fontsize=10)
    ax.text(x+w/2,y+h*.34,body,ha='center',va='center',fontsize=9,linespacing=1.35)
def arrow(ax,start,end,color='#68808c'):
    ax.add_patch(FancyArrowPatch(start,end,arrowstyle='-|>',mutation_scale=12,lw=1.3,color=color))

fig,ax=plt.subplots(figsize=(9.5,3.9));ax.set_xlim(0,1);ax.set_ylim(0,1);ax.axis('off')
box(ax,.02,.62,.22,.24,'1. Draft and revise','1,024 fitting examples\nInspect fitting errors')
box(ax,.32,.62,.22,.24,'2. Select','512 validation examples\nAggregate accuracy only')
box(ax,.62,.62,.35,.24,'3. Freeze','Policy + model + settings\nBefore new test inference')
arrow(ax,(.25,.74),(.31,.74));arrow(ax,(.55,.74),(.61,.74))
box(ax,.02,.08,.52,.29,'Grouped WildGuardTrain partitions','86,759 rows -> 47,617 lexical groups\n69,366 fit / 8,700 validation / 8,693 audit\nModel-generated training labels')
box(ax,.62,.08,.35,.29,'4. Evaluate','WildGuardTest: 1,699 labeled rows\nHuman labels; all failures retained\nPlus 512-row internal audit',color='#e9f4ef')
arrow(ax,(.79,.60),(.79,.39));arrow(ax,(.13,.39),(.13,.60));arrow(ax,(.43,.39),(.43,.60))
ax.text(.5,.97,'Five candidates per model; weights stay fixed',ha='center',fontsize=10,fontweight='bold')
save(fig,'protocol')

fig,ax=plt.subplots(figsize=(9.5,3.6));ax.set_xlim(0,1);ax.set_ylim(0,1);ax.axis('off')
ax.text(.02,.94,'Hosted API: organization and provider both influence the decision path',fontsize=10,fontweight='bold')
box(ax,.02,.60,.20,.21,'Policy + content','Organization supplies')
box(ax,.31,.60,.31,.21,'Provider-controlled service','Model + filters + routing',color='#fff1e5')
box(ax,.72,.60,.25,.21,'Observed outcome','Label, refusal, or error')
arrow(ax,(.23,.705),(.30,.705));arrow(ax,(.63,.705),(.71,.705))
ax.text(.02,.43,'Self-hosted model: more control over the serving path',fontsize=10,fontweight='bold')
box(ax,.02,.10,.20,.21,'Policy + content','Organization supplies')
box(ax,.31,.10,.31,.21,'Operator-controlled service','Pinned model + adapter + rules',color='#e9f4ef')
box(ax,.72,.10,.25,.21,'Observed outcome','Label or model/runtime failure')
arrow(ax,(.23,.205),(.30,.205));arrow(ax,(.63,.205),(.71,.205))
ax.text(.5,.005,'Control over serving does not guarantee policy fidelity or remove learned model behavior.',ha='center',fontsize=9)
save(fig,'deployment-control')

from build_transfer_assets import build as build_transfer
SOURCES.update(build_transfer())

(OUT/'evidence-manifest.json').write_text(json.dumps({'repository_commit':'0b873f611fd6c90cd77c1d0423044f64e5a933ec','sources_sha256':SOURCES,'figures':'Generated from the archived JSON; conceptual diagrams are explicitly illustrative.'},indent=2)+'\n')
from build_workflow_figure import build as build_authoring_workflow
build_authoring_workflow()
print('Generated 7 figures (5 used in v0.4), 9 LaTeX table/text files, two results CSVs, policy copies, and evidence manifest.')
