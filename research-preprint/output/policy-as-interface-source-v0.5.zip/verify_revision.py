"""Check the three revised articles against frozen evidence and their scope constraints."""
from pathlib import Path
import json,hashlib,re,zipfile
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parent

def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    before=load(ROOT/'generated/experiments-before-rewrite.json')
    assert all(sha(REPO/p)==h for p,h in before.items()),'An experiment file changed'
    for directory,version in [('research-preprint','v0.4'),('research-magazine','v0.3'),('research-media','v0.2')]:
        arc=REPO/directory/'archive'/version
        with zipfile.ZipFile(arc/'before-2026-10-28-rewrite.zip') as z:
            manifest=load(arc/'manifest.json')
            assert all(hashlib.sha256(z.read(p)).hexdigest()==h for p,h in manifest.items())
    ext=ROOT/'generated/extensions'
    for rel,h in load(ext/'manifest.json').items():
        assert sha(REPO/rel)==h
        for article in [ROOT,REPO/'research-magazine',REPO/'research-media']:
            assert sha(article/'generated/extensions'/Path(rel).relative_to('published_runs'))==h
    records={c:load(REPO/'published_runs/2026-10-28-ensemble-logits/cohorts'/c/'results.json') for c in ['wildguard-specialists','hatexplain-specialists','hatexplain-mixed']}
    metrics={c:d['all_candidates'][d['selection']['primary']]['metrics'] for c,d in records.items()}
    assert [f"{m['accuracy']*100:.2f}" for m in metrics.values()]==['91.29','78.79','80.82']
    wg=metrics['wildguard-specialists'];wb=records['wildguard-specialists']['all_candidates']['wildguard-baseline']['metrics']
    hx=metrics['hatexplain-mixed'];hs=records['hatexplain-mixed']['all_candidates']['single/shieldstral/logistic-C0.01']['metrics']
    assert round((wg['accuracy']-wb['accuracy'])*1699)==16
    assert (wg['false_blocks'],wg['missed_violations'],wb['false_blocks'],wb['missed_violations'])==(61,87,51,113)
    assert round((hx['accuracy']-hs['accuracy'])*1924)==24
    assert hs['false_blocks']-hx['false_blocks']==34 and hx['missed_violations']-hs['missed_violations']==10
    assert metrics['hatexplain-specialists']['accuracy'] < hs['accuracy']
    prior=load(REPO/'published_runs/2026-10-27-ensemble/cohorts/hatexplain-specialists/results.json')
    fixed=prior['all_candidates']['single/shieldstral/fixed']['metrics']
    assert f"{fixed['accuracy']*100:.2f}"=='53.17'
    assert (fixed['false_blocks'],fixed['missed_violations'])==(885,16)
    # Verify all percentages displayed in manuscript prose against recorded metrics.
    sources=[REPO/'published_runs'/day/'analysis.json' for day in ['2026-10-24-wildguard','2026-10-25-qwen','2026-10-25-policy-transfer','2026-10-26-hatexplain']]
    sources += list((REPO/'published_runs/2026-10-27-ensemble/cohorts').glob('*/results.json'))
    sources += list((REPO/'published_runs/2026-10-28-ensemble-logits/cohorts').glob('*/results.json'))
    sources += list((REPO/'published_runs/2026-10-27-ensemble/cohorts').glob('*/selection.json'))
    allowed={'99.4'} # separately checked below as a learned weight
    def walk(obj):
        if isinstance(obj,dict):
            for k,v in obj.items():
                if isinstance(v,(int,float)) and any(word in k for word in ['accuracy','f1','recall','rate','weight']):
                    allowed.update(f'{v*100:.{n}f}' for n in [1,2])
                walk(v)
        elif isinstance(obj,list):
            for v in obj:walk(v)
    for p in sources:walk(load(p))
    paper=(ROOT/'main.tex').read_text()+'\n'+'\n'.join(p.read_text() for p in (ROOT/'sections').glob('*.tex') if p.name!='frontier.tex')
    percentages=set(re.findall(r'(\d+\.\d+)\\%',paper))
    assert percentages<=allowed, percentages-allowed
    old=load(REPO/'published_runs/2026-10-27-ensemble/cohorts/wildguard-specialists/selection.json')
    # Actual retained weight also appears in the frozen RESULTS.md.
    assert '0.994' in json.dumps(old) or '99.4' in (REPO/'published_runs/2026-10-27-ensemble/RESULTS.md').read_text()
    abstract=(ROOT/'main.tex').read_text().split('\\begin{abstract}')[1].split('\\end{abstract}')[0]
    assert 'frontier' not in abstract.lower() and 'OpenRouter' not in abstract
    main_body='\n'.join((ROOT/'sections'/n).read_text() for n in ['introduction.tex','methods.tex','results.tex','discussion.tex'])
    assert 'frontier' not in main_body.lower()
    for prohibited in ['fine-tuning is unnecessary','policy text alone is sufficient','universal model superiority']:
        assert prohibited not in main_body
    assert 'log-odds' in main_body and 'without additional' in main_body and 'reused' in main_body
    assert sha(ROOT/'figures/policy-edits.pdf')==sha(REPO/'research-magazine/figures/policy-edits.pdf')
    expected=[]
    choices=[('wildguard-specialists','WG released WildGuard','wildguard-baseline'),('wildguard-specialists','WG earlier single','prior_best_single'),('wildguard-specialists','WG new selected single','best_single'),('wildguard-specialists','WG log-odds ensemble','primary'),('hatexplain-specialists','HX calibrated Shieldstral','best_single'),('hatexplain-specialists','HX specialist ensemble','primary'),('hatexplain-mixed','HX selected Qwen individual','best_single'),('hatexplain-mixed','HX mixed ensemble','primary')]
    for c,label,key in choices:
        d=records[c];m=d['all_candidates'][d['selection'].get(key,key)]['metrics']
        expected.append(f"{label} & {m['accuracy']*100:.2f} & {m['macro_f1']*100:.2f} & {m['false_blocks']} & {m['missed_violations']} \\\\")
    assert (ROOT/'generated/ensemble-details.tex').read_text()=='\n'.join(expected)+'\n'
    report={'status':'passed','date':'2026-10-28','experiment_files_unchanged':len(before),'prior_versions_archived':3,'paper_percentages_checked':sorted(percentages),'source_sha256':{str(p.relative_to(REPO)):sha(p) for p in sources},'extension_table_rows':len(expected),'frontier_only_in_appendix':True,'editorial_review':'One substantive read-through followed by fact and layout repairs. Wording, calibration and ensemble gains remain separate; no matched fine-tuning, enterprise, multilingual, review-routing or production claims.','no_new_inference':True,'no_additional_paid_compute':True}
    (ROOT/'generated/revision-claim-checks.json').write_text(json.dumps(report,indent=2)+'\n')
    print('Passed:',len(percentages),'displayed percentage values;',len(before),'unchanged experiment files; three preserved prior drafts.')
if __name__=='__main__':main()
