"""Build Study C manuscript assets from its immutable, prompt-free evidence."""
from pathlib import Path
import csv
import hashlib
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

HERE = Path(__file__).resolve().parent
REPO = HERE.parent
BASE = 'published_runs/2026-10-25-policy-transfer'
MODELS = ['policylm', 'shieldstral', 'qwen-2b', 'qwen-4b', 'qwen-27b']
NAMES = ['PolicyLM-1.7B', 'Shieldstral-3B', 'Qwen3.5-2B', 'Qwen3.5-4B', 'Qwen3.5-27B']
POLICIES = ['wg-p0-taxonomy', 'transfer-policylm-p2', 'transfer-shieldstral-p3', 'transfer-qwen-2b-p3']
SHORT = dict(zip(POLICIES, ['p0', 'PolicyLM p2', 'Shieldstral p3', 'Qwen 2B p3']))

def build():
    sources = {}
    def read(file):
        path = REPO / BASE / file
        sources[str(path.relative_to(REPO))] = hashlib.sha256(path.read_bytes()).hexdigest()
        return json.loads(path.read_text())
    a = read('analysis.json')
    selection = read('source-selection.json')
    freeze = read('freeze.json')
    for file in ['registry.json', 'coverage.json', 'repeatability.json', 'candidates.json']:
        read(file)
    out = HERE / 'generated'
    out.mkdir(exist_ok=True)
    row = lambda *v: ' & '.join(map(str, v)) + r' \\' + '\n'
    pct = lambda v: f'{100*v:.2f}'
    selected_rows, metric_rows, data = [], [], []
    for slug, name in zip(MODELS, NAMES):
        own = selection['selected'][slug]
        pool = freeze['recipient_choice'][slug]
        assert own['id'] == a['source_selected'][slug]
        assert pool['id'] == a['pool_selected'][slug]
        selected_rows.append(row(name, SHORT[own['id']], own['words'], pct(own['accuracy']),
                                 SHORT[pool['id']], pct(pool['accuracy'])))
        m = a['matrix']['test'][slug][pool['id']]
        metric_rows.append(row(name, pct(m['accuracy']), pct(m['harmful_f1']),
                               pct(m['harmful_recall']), pct(m['benign_false_positive_rate']), m['errors']))
        for pid in POLICIES:
            m = a['matrix']['test'][slug][pid]
            assert m['n'] == 1699 and m['errors'] == 0
            data.append(dict(model=slug, policy=pid, selected_on_validation=pid == pool['id'],
                             **{k:m[k] for k in ['n','accuracy','harmful_f1','harmful_recall','benign_false_positive_rate','errors']}))
    (out / 'transfer-selection.tex').write_text(''.join(selected_rows))
    (out / 'transfer-metrics.tex').write_text(''.join(metric_rows))
    with (out / 'transfer-results.csv').open('w') as handle:
        w = csv.DictWriter(handle, fieldnames=data[0].keys())
        w.writeheader(); w.writerows(data)
    values = [[100*a['matrix']['test'][m][p]['accuracy'] for p in POLICIES] for m in MODELS]
    with plt.rc_context({'font.family':'DejaVu Sans','font.size':12,'pdf.fonttype':42,
                         'ps.fonttype':42,'svg.fonttype':'none','text.color':'#243447'}):
        fig, ax = plt.subplots(figsize=(8.3, 4.2))
        ax.imshow(values, cmap='Blues', vmin=70, vmax=100, aspect='auto')
        ax.set_xticks(range(4), ['Initial\np0', 'PolicyLM\nchoice', 'Shieldstral\nchoice', 'Qwen 2B\nchoice'])
        ax.set_yticks(range(5), NAMES)
        ax.tick_params(length=0, pad=9)
        ax.xaxis.tick_top()
        ax.set_ylabel('Recipient model', labelpad=12)
        for i, slug in enumerate(MODELS):
            for j, pid in enumerate(POLICIES):
                ax.text(j, i, f'{values[i][j]:.2f}', ha='center', va='center',
                        fontsize=14, color='white' if values[i][j] >= 87 else '#183247')
                if a['pool_selected'][slug] == pid:
                    ax.add_patch(Rectangle((j-.44,i-.41), .88,.82, fill=False,
                                           edgecolor='#f2af26', linewidth=2.5))
        ax.set_xticks([-.5,.5,1.5,2.5,3.5], minor=True)
        ax.set_yticks([-.5,.5,1.5,2.5,3.5,4.5], minor=True)
        ax.grid(which='minor', color='white', linewidth=2)
        ax.tick_params(which='minor',length=0)
        for spine in ax.spines.values(): spine.set_visible(False)
        ax.set_xlabel('Test accuracy (%)     Outline: recipient choice on validation', labelpad=12, fontsize=11)
        fig.tight_layout()
        for ext in ['pdf','png','svg']:
            kw = {'dpi':180} if ext == 'png' else {}
            if ext == 'pdf': kw['metadata']={'Creator':'build_transfer_assets.py; archived Study C results'}
            fig.savefig(HERE/'figures'/f'policy-transfer.{ext}', bbox_inches='tight', **kw)
        plt.close(fig)
    return sources

if __name__ == '__main__':
    source_hashes = build()
    print(f'Generated Study C figure, two tables and CSV from {len(source_hashes)} archived inputs.')
