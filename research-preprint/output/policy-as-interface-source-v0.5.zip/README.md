# Policy as an Interface

Author review **v0.5**, 28 October 2026. The central message is that policy authoring is deeply coupled with AI engineering. Teams can obtain competitive classification results with released models, policy revision, labeled evaluation, calibration, and lightweight ensembles, without additional language-model fine-tuning by the deploying team.

## Read and edit

- [Current PDF](output/pdf/policy-as-interface-review-v0.5.pdf).
- [Editable LaTeX project](main.tex), with prose in `sections/`.
- [Portable source package](output/policy-as-interface-arxiv-source-v0.5.zip).
- [Revision plan and editorial decisions](REVISION-v0.5.md).
- [Evidence verification](generated/revision-claim-checks.json).

The main narrative occupies pages 1–12. References and technical appendices follow. Start with the introduction, then Sections 4 and 5: what changing the policy taught us, followed by what changing the decision layer taught us. Section 6 explains the shared responsibility of policy owners and engineers. Exact model identities, detailed controls, equations and numerical comparisons remain available in the appendices.

## What changed

The earlier three WildGuard studies now lead into the HateXplain structure/omission/transfer study and both ensemble stages. Six studies are presented as a sequence of questions, not independent replications. Concrete policy edits appear before their scores. The writing separates three sources of improvement: wording, calibration/decision thresholds, and score combination.

The new log-odds result reuses saved probabilities; it is not a new capture of raw logits or activations. The manuscript retains the failed HateXplain specialist ensemble, the mixed ensemble's false-block/missed-hate tradeoff, and the earlier WildGuard equal average that scored above the latest primary method. It does not claim an ensemble always wins.

“No additional language-model fine-tuning” is scoped to our adaptation of released checkpoints. Creators already trained those models, and our calibrators/combiners use labels. No matched fine-tuning baseline, full development-cost study, professional-team study, or validated enterprise deployment was performed. Later test reuse and unknown upstream benchmark exposure remain explicit. The frontier API pilot remains only in Appendix G; there is none in the abstract or main discussion.

The research paper addresses policy-aware ML practitioners and researchers. The companion magazine follows a moderation release workflow; the media article focuses on the changing work of policy authors. They share the evidence without sharing the same level of technical detail.

## Build and verify

The included figures, generated tables and bibliography are sufficient for offline compilation once TeX dependencies are installed:

```sh
tectonic --keep-logs --keep-intermediates main.tex
```

A conventional installation can use `pdflatex`, `bibtex`, then two more `pdflatex` passes. The desktop LaTeX editor also compiles this existing project.

Within the full repository, `build_extension_assets.py` copies prompt-free evidence summaries for the added studies and generates the detailed ensemble table. `verify_revision.py` checks numerical claims, copied evidence, archived prior documents, and unchanged experiment hashes. The original `build_assets.py`, `build_transfer_assets.py`, and `build_workflow_figure.py` remain available for earlier assets. Use the documented Python dependencies in the repository or bundled authoring runtime as appropriate; no model calls are made.

The portable source ZIP includes all used PDF figures, generated tables, `main.bbl`, references, the 41 original policies, seven HateXplain policies with their license notice, and prompt-free extension analyses/selections. It excludes source datasets, private traces, credentials and environments. Full row-level reproduction requires the corresponding `published_runs/` bundles, not only this manuscript package.

## Preservation and provenance

Prior PDFs and source ZIPs remain in `output/`. The pre-edit v0.4 working files are preserved under `archive/v0.4/`, with checksums. The revision hashes all 3,030 existing experiment files and checks that none changed. Updated claims are drawn from the frozen October 24–28 evidence, not from new inference.

Earlier public evidence is identified at repository snapshot `0b873f6`; the later studies are supplied as local companion records. The source package does not imply that every later bundle exists at that old public commit.

The user's framing and existing experiments supplied the argument and findings. AI assistance supplied the revised prose and document preparation. The pinned [Clarity guidance](https://github.com/addyosmani/clarity/blob/e27ceeff60368cf6966b4ea00a5b9b36418ee9a0/SKILL.md) informed one substantive editorial review; subsequent repairs concerned facts and layout. No first-person career history was invented. This is a review draft, not a submitted, accepted, or peer-reviewed paper. No new inference or paid service was used for this rewrite.
