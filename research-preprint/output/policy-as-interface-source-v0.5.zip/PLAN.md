# Review draft: plan and progress

Current audience: Trust and Safety professionals, policy development teams, and content moderation engineers; ML researchers are a secondary audience. GRC relevance is a proposed extension to enterprise governance, not an evaluated use case. Use a readable single-column article, explain experimental terms when introduced, and put operational detail in appendices.

Current scope: six exploratory studies on WildGuard and HateXplain, including structure/omission/transfer and both score-ensemble stages. The earlier frontier pilot remains in Appendix G only. See [the v0.5 cross-document plan](REVISION-v0.5.md) for the current revision. Historical version records below retain their original scope and appendix numbering.

Current evidence: the October 24–28 frozen run bundles. The earlier public snapshot is `0b873f6`; later companion evidence is local. Do not change predictions, selections, freezes or archived source. No inference or publication is needed for this writing revision.

- [x] Read methods, claims, policy ledgers, selections, and archived results.
- [x] Verify primary dataset, model, prompting, and arXiv source-format references.
- [x] Generate tables and vector figures directly from archived JSON.
- [x] Draft motivation, related work, methods, results, governance discussion, limitations, and future experiments.
- [x] Include exact policy versions, model revisions, evidence pointers, and AI-assistance disclosure.
- [x] Compile the LaTeX project and export a PDF.
- [x] Check numerical transcription, citations, and every rendered page.
- [x] Package portable LaTeX sources and provide a short review guide.

Framing decisions:

1. No claim of superiority to fine-tuning: no new matched fine-tuning experiment was run.
2. The supplied policy is an instruction in both specialist and general-purpose settings.
3. Self-hosting offers control over serving and versioning; it does not erase learned refusals or establish policy fidelity.
4. The API pilot has only 32 unique fitting examples, of which three are labeled harmful. Four content-filter responses correspond to two unique prompts across two settings. It cannot establish how often frontier APIs fail in production.
5. The frontier pilot used only p0. New policy tuning and official-test inference remain pending.
6. Paper remains a review draft. No arXiv submission or public manuscript publication is authorized by this drafting task.

## Clarity rewrite — v0.2

Requested scope: rewrite the paper using Clarity; discuss frontier comparisons only in the appendix, with none in the abstract or main body.

Reader: an ML researcher or engineer who knows LLMs but needs the selection process and its limits explained plainly. Intended takeaway: policy text can change classification results, but observed gains require validation, threshold controls, and careful separation from claims about general policy fidelity.

- [x] Read Clarity’s rewrite, academic-medium, and long-form guidance.
- [x] Inventory the existing claims, citations, results, and qualifications.
- [x] Rewrite the abstract, motivation, methods, results, discussion, and appendix prose.
- [x] Consolidate frontier comparisons and deployment discussion in Appendix F.
- [x] Verify unchanged numerical table fragments, policy excerpts, and citation keys.
- [x] Compile without LaTeX warnings.
- [x] Review every rendered page and complete the editorial self-review.
- [x] Verify the portable source package and export v0.2.
- [x] Request the existing LaTeX project for review (Codex returned queued; opens when this chat is shown).

Preserve v0.1 exports. Do not modify archived experiments, run models, spend on inference, or publish the manuscript.


## Policy-authoring theme — v0.3

Author feedback: make policy development and application a shared governance task across GRC, Trust and Safety, and engineering. Remove the religious-iconography motivation. Help policy authors understand why writing and testing rules deserve the same care as selecting the interpreting model.

- [x] Preserve v0.2 exports and inventory the evidence and scope constraints.
- [x] Revise title, abstract, introduction, methods framing, results interpretation, discussion, and future work around policy authoring.
- [x] Add a clearly labeled conceptual diagram of shared responsibilities and joint review.
- [x] Keep frontier comparisons in Appendix F only; preserve all measured results and archived policies.
- [x] Check scientific qualifications, compile, and inspect every rendered page.
- [x] Export and independently compile v0.3 sources; update review notes and request the existing project in Codex (queued).

Guardrail for the argument: the evidence supports evaluating policy text alongside model choice. It does not estimate an equal numerical contribution from each, test professional authoring teams, or prove a production governance benefit. Present the cross-functional workflow as a recommendation, not an observed study result.

## Policy authoring as classifier development — v0.4

Requested message: policy teams should take responsibility for authored policy text as developers do for code. The policy model interprets that text; both must be selected, tested, and versioned together. Explain the evidence for involving policy owners and engineering without claiming we measured organizational collaboration. The interpreter analogy describes responsibility and deployment dependence, not formal or deterministic semantics.

Current scope: three completed studies — specialist policy search, nearby-size Qwen comparisons, and source-isolated policy transfer — plus the earlier API pilot in Appendix F only. Source snapshot: `0b873f611fd6c90cd77c1d0423044f64e5a933ec`. No new inference, spending, edits to archived runs, or public manuscript publication.

- [x] Inspect the existing manuscript and completed transfer-study evidence.
- [x] Read the previously pinned Clarity guidance and PDF workflow.
- [x] Rewrite the abstract and introduction around author responsibility and the policy/model combination.
- [x] Explain each study's question, design, results, and implications for policy authors and engineers.
- [x] Include all transfer combinations, negative results, scope concerns, and the earlier stronger Qwen 27B result.
- [x] Generate added tables/figures from archived evidence and retain all 41 authored policy texts.
- [x] Verify numbers, citations, archive integrity, and the limits of the code/interpreter analogy.
- [x] Compile the existing project and visually inspect every page.
- [x] Preserve prior exports, independently compile the v0.4 source package, and update the review guide.

Editorial checks: no claim that every model needs a successful rewrite; no claim that policy editing beats fine-tuning; no general small-model superiority; no inference about hidden weights or organizational effectiveness. Benchmark label agreement and policy fidelity remain separate. Policy meaning needs owner approval independently of validation accuracy.
