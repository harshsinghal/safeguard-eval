# Three audience revision plan

28 October 2026. Authorized rewrite; no new inference or publication.

Central claim: policy authoring is deeply coupled with AI engineering. Released models can be adapted through policy writing, labeled evaluation, calibration, and lightweight score combination without additional language-model weight updates by the deploying team.

## Progress

- [x] Inspect existing drafts and immutable evidence. Confirm media DOCX matches source and contains no reviewer changes.
- [x] Archive preprint v0.4, magazine v0.3 and media v0.2 before editing.
- [x] Rewrite preprint v0.5 around the experimental questions; add HateXplain and both ensemble stages.
- [x] Rewrite magazine v0.4 around the moderation release workflow.
- [x] Rewrite media v0.3 around the changing work of policy authors.
- [x] Verify numerical claims against frozen records, preserve evidence hashes, compile and render every page.
- [x] Export portable sources and queue the three final documents in the review panel.

Final checks: the 25-page paper and six-page magazine compile in the desktop
editor and from independently extracted source archives. Extracted PDF text and
page geometry match their exports. Every rendered page was inspected. The
four-page, 1,426-word media DOCX matches its JSON source, retains all six embedded
source links, and contains no tracked changes or comments. Prior versions remain
archived. The app accepted all three open requests with `queued` status.

## Audience and editorial decisions

The research paper addresses ML practitioners and policy researchers. It should make the intervention and its limits easy to follow, with exact technical details in appendices. The magazine follows a trust and safety professional from rules and annotation guidance to policy instructions, error review and release decisions. The media article is contributed analysis for a general technology reader, using explicitly hypothetical scenes and a small number of supporting results. No invented reporting, deployment, interviews or personal career history.

The three interventions remain distinct: text edits, decision cutoff/calibration, and combination of scores. The log-odds extension holds policy text fixed and reconstructs decision margins from saved probabilities; it does not collect raw logits or new activations. Specialist-only HateXplain ensembling failed to beat its strongest individual. Preserve that result and the higher historical WildGuard equal-average result.

All studies use binary decisions. No validated REVIEW routing, images, multilingual, enterprise intent or production claims. Later studies reuse known tests and are exploratory. The model creators already trained the checkpoints; calibrators and combiners learn from labels. No matched fine-tuning, human-effort or end-to-end cost comparison. Frontier API pilot stays in the research appendix and out of the abstract, magazine and media article.

Clarity rewrite, long-form and academic guidance at pinned revision e27ceeff60368cf6966b4ea00a5b9b36418ee9a0 informs one substantive editorial review. Sources are the user's narrative, existing drafts and frozen experiment archives. Model assistance supplies connective prose, not personal experience.
