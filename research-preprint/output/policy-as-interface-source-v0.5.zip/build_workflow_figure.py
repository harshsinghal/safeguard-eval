"""Render the proposed policy-authoring workflow; no empirical data or model calls."""
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch


def build():
    out = Path(__file__).resolve().parent / 'figures'
    out.mkdir(exist_ok=True)
    with plt.rc_context({'font.family': 'DejaVu Sans', 'pdf.fonttype': 42,
                         'ps.fonttype': 42, 'svg.fonttype': 'none',
                         'text.color': '#243447'}):
        fig, ax = plt.subplots(figsize=(9.5, 4.5))
        fig.subplots_adjust(left=.015, right=.985, top=.985, bottom=.015)
        ax.set(xlim=(0, 1), ylim=(0, 1))
        ax.axis('off')

        def box(x, y, w, h, title, body, fill):
            ax.add_patch(FancyBboxPatch((x, y), w, h,
                boxstyle='round,pad=0.009,rounding_size=0.018',
                fc=fill, ec='#a8bec9', lw=1.1))
            ax.text(x+w/2, y+h*.77, title, ha='center', va='center',
                    fontsize=11.2, fontweight='bold')
            ax.text(x+w/2, y+h*.34, body, ha='center', va='center',
                    fontsize=10.5, linespacing=1.4)

        def arrow(start, end, style='-', connection='arc3'):
            ax.add_patch(FancyArrowPatch(start, end, arrowstyle='-|>',
                mutation_scale=12, lw=1.3, color='#66818e',
                linestyle=style, connectionstyle=connection))

        box(.025, .70, .43, .25, 'Policy development / Trust & Safety',
            'Author rules and exceptions;\napprove scope and changes', '#edf4f6')
        box(.545, .70, .43, .25, 'Content moderation engineers',
            'Choose model, adapter and cutoff;\nverify runtime behavior', '#edf4f6')
        box(.20, .32, .60, .24, 'Joint review of policy and behavior',
            'Review the policy diff and changed decisions\nInspect misses, false blocks and scope', '#e8f3ee')
        box(.20, .015, .60, .19, 'Approve and version the configuration',
            'Policy + model + threshold + evaluation record', '#f3f5f7')
        arrow((.33, .685), (.39, .575))
        arrow((.67, .685), (.61, .575))
        arrow((.50, .305), (.50, .22))
        arrow((.185, .44), (.08, .685), '--', 'angle,angleA=180,angleB=-90,rad=8')
        arrow((.815, .44), (.92, .685), '--', 'angle,angleA=0,angleB=-90,rad=8')
        ax.text(.085, .59, 'Revise\nrules', ha='center', va='center', fontsize=9.5,
                bbox={'facecolor': 'white', 'edgecolor': 'none', 'pad': 2})
        ax.text(.915, .59, 'Adjust\nimplementation', ha='center', va='center', fontsize=9.5,
                bbox={'facecolor': 'white', 'edgecolor': 'none', 'pad': 2})
        for ext in ['pdf', 'svg', 'png']:
            kwargs = {'dpi': 180} if ext == 'png' else {}
            if ext == 'pdf':
                kwargs['metadata'] = {'Creator': 'build_workflow_figure.py; proposed conceptual workflow'}
            fig.savefig(out / f'policy-authoring-workflow.{ext}', bbox_inches='tight', **kwargs)
        plt.close(fig)


if __name__ == '__main__':
    build()
