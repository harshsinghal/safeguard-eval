"""Copy prompt-free extension evidence and generate the appendix table. No inference."""
from pathlib import Path
import json, shutil, hashlib
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parent
COHORTS=['wildguard-specialists','hatexplain-specialists','hatexplain-mixed']

def load(p):return json.loads(p.read_text())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def build():
    sources=[Path('published_runs/2026-10-26-hatexplain')/x for x in ['analysis.json','freeze.json','cpu-reproduction.json']]
    # Use only files present in the frozen archive; no private prompts or traces.
    sources=[p for p in sources if (REPO/p).exists()]
    for day in ['2026-10-27-ensemble','2026-10-28-ensemble-logits']:
        for c in COHORTS:
            for name in ['results.json','selection.json','freeze.json']:
                sources.append(Path('published_runs')/day/'cohorts'/c/name)
        for name in ['reproduction.json','equations.json','descriptive-comparison.json','PLAN.md','README.md','RESULTS.md']:
            p=Path('published_runs')/day/name
            if (REPO/p).exists():sources.append(p)
    for target in [ROOT,REPO/'research-magazine',REPO/'research-media']:
        out=target/'generated/extensions';out.mkdir(parents=True,exist_ok=True)
        for rel in sources:
            dst=out/rel.relative_to('published_runs');dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(REPO/rel,dst)
        (out/'manifest.json').write_text(json.dumps({str(p):digest(REPO/p) for p in sources},indent=2)+'\n')
    rows=[]
    records={c:load(REPO/'published_runs/2026-10-28-ensemble-logits/cohorts'/c/'results.json') for c in COHORTS}
    choices=[('wildguard-specialists','WG released WildGuard','wildguard-baseline'),
        ('wildguard-specialists','WG earlier single','prior_best_single'),
        ('wildguard-specialists','WG new selected single','best_single'),
        ('wildguard-specialists','WG log-odds ensemble','primary'),
        ('hatexplain-specialists','HX calibrated Shieldstral','best_single'),
        ('hatexplain-specialists','HX specialist ensemble','primary'),
        ('hatexplain-mixed','HX selected Qwen individual','best_single'),
        ('hatexplain-mixed','HX mixed ensemble','primary')]
    for cohort,label,key in choices:
        d=records[cohort];cid=d['selection'].get(key,key);m=d['all_candidates'][cid]['metrics']
        rows.append(f"{label} & {m['accuracy']*100:.2f} & {m['macro_f1']*100:.2f} & {m['false_blocks']} & {m['missed_violations']} \\\\")
    (ROOT/'generated/ensemble-details.tex').write_text('\n'.join(rows)+'\n')
    print(f'Copied {len(sources)} prompt-free companion records to each article; generated eight table rows.')

if __name__=='__main__':build()
