"""Create manuscript tables/figures from frozen evidence; no inference or selection.

Use --evidence-root to refresh the exact prompt-free inputs from a checkout.
Without it, the portable paper package builds from its bundled evidence copies.
"""
from pathlib import Path
import argparse
import hashlib
import json
import shutil

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "generated/leaderboard-evidence"
SOURCES = {
    "results.json": "published_runs/2026-10-29-leaderboard-decision-models/results.json",
    "selection.json": "published_runs/2026-10-29-leaderboard-decision-models/selection.json",
    "coverage.json": "published_runs/2026-10-29-leaderboard-decision-models/coverage.json",
    "policy-contrasts.json": "published_runs/2026-10-29-decision-models/policy-contrasts.json",
    "model-card-references.json": "published_runs/2026-10-29-decision-models/model-card-references.json",
    "jev-results.json": "published_runs/2026-10-29-jev/results.json",
}
METHODS = {"logit-equal": "Equal log-odds", "logit-logistic": "Log-odds LR",
           "logistic": "Probability LR", "equal-calibrated": "Calibrated mean",
           "forest": "Random forest", "equal-raw": "Raw mean", "weighted": "Weighted mean"}
COLORS = {"Specialist": "#156f83", "General-purpose": "#9252a1", "Typed classifier": "#c06519",
          "Ensemble": "#244b7b", "Task-specific baseline": "#5f6368"}

def short(row):
    group = row["group"]
    if row["category"] == "Ensemble":
        cohort, method = group.split("/")
        return ("M: " if cohort.endswith("mixed") else "S: ") + METHODS[method]
    return row["label"].replace("GPT-OSS Safeguard", "Safeguard")

def pct(value):
    return "--" if value is None else f"{100 * value:.2f}"

def tex(text):
    return str(text).replace("&", r"\&").replace("_", r"\_").replace("%", r"\%")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--evidence-root", type=Path)
    args = parser.parse_args()
    DATA.mkdir(parents=True, exist_ok=True)
    if args.evidence_root:
        for name, source in SOURCES.items():
            shutil.copy2(args.evidence_root / source, DATA / name)
        (DATA / "manifest.json").write_text(json.dumps({name: {"source": src, "sha256": hashlib.sha256((DATA/name).read_bytes()).hexdigest()} for name, src in SOURCES.items()}, indent=2) + "\n")
    for name, record in json.loads((DATA/"manifest.json").read_text()).items():
        assert hashlib.sha256((DATA/name).read_bytes()).hexdigest() == record["sha256"]
    data = json.loads((DATA/"results.json").read_text())["datasets"]
    contrasts = json.loads((DATA/"policy-contrasts.json").read_text())
    all_rows = {}
    for ds in ["wildguard", "hatexplain"]:
        rows = data[ds]["profiles"]["balanced"]["rows"]
        assert len(rows) == 20
        all_rows[ds] = {r["group"]: r for r in rows}
        table, errors, choices = [], [], []
        for r in rows:
            m, ci = r["metrics"], r["ci95"]["balanced_accuracy"]
            table.append(" & ".join([tex(short(r)), pct(m["balanced_accuracy"]), f"[{pct(ci[0])}, {pct(ci[1])}]", pct(m["accuracy"]), pct(m["macro_f1"]), "--" if m["mcc"] is None else f"{m['mcc']:.3f}"]) + r" \\")
            errors.append(" & ".join([tex(short(r)), pct(m["recall"]), pct(m["false_positive_rate"]), pct(m["false_negative_rate"]), str(m["false_blocks"]), str(m["missed_violations"]), str(m["unresolved"])]) + r" \\")
            choices.append({"entry": short(r), **{k:r[k] for k in ["group", "candidate", "policy", "threshold", "candidate_count", "source_archive", "model_id", "adapter"]}})
        (ROOT/f"generated/leaderboard-{ds}.tex").write_text("\n".join(table)+"\n")
        (ROOT/f"generated/leaderboard-{ds}-errors.tex").write_text("\n".join(errors)+"\n")
        (ROOT/f"generated/leaderboard-{ds}-choices.json").write_text(json.dumps(choices, indent=2)+"\n")
    # A short table makes decision-policy contrasts inspectable in the main text.
    lines = []
    for model in ["kev", "clef"]:
        for policy in ["brief", "detailed", "examples"]:
            c = contrasts[f"{model}/hatexplain"][policy]
            lines.append(" & ".join([model.title(), {"brief":"Brief", "detailed":"Detailed", "examples":"Detailed + examples"}[policy], pct(c["native"]["balanced_accuracy"]), pct(c["tuned"]["balanced_accuracy"]), f"{c['validation_selected_threshold']:.2f}", f"{c['native']['auroc']:.3f}"]) + r" \\")
    (ROOT/"generated/decision-policy-contrasts.tex").write_text("\n".join(lines)+"\n")
    # Shared summary plots are generated only from the frozen choices above.
    plt.rcParams.update({"font.family":"DejaVu Sans", "font.size":12.5, "axes.spines.top":False,
                         "axes.spines.right":False, "axes.spines.left":False,
                         "pdf.fonttype":42, "ps.fonttype":42})
    fig, axes = plt.subplots(1, 2, figsize=(10.4, 5.2), gridspec_kw={"wspace":.72})
    wanted = {
        "wildguard":["wildguard-specialists/logit-equal", "cope", "shieldstral", "qwen-27b", "wildguard", "jev", "clef", "kev", "qwen-4b", "policylm"],
        "hatexplain":["hatexplain-mixed/logit-logistic", "jev", "shieldstral", "qwen-4b", "kev", "clef", "policylm"]}
    for ax, ds, title, lim in zip(axes, wanted, ["WildGuardTest · 1,699 requests", "HateXplain · 1,924 posts"], [(81,94),(60,84)]):
        selected = [all_rows[ds][g] for g in wanted[ds]]
        for i,r in enumerate(selected):
            v = 100*r["metrics"]["balanced_accuracy"]
            lo,hi = [100*x for x in r["ci95"]["balanced_accuracy"]]
            ax.errorbar(v, i, xerr=[[v-lo],[hi-v]], fmt="o", ms=5, lw=1.4, capsize=2,
                        color=COLORS.get(r["category"], "#5f6368"))
            ax.text(lim[1]+.25, i, f"{v:.2f}", va="center", fontsize=11, color="#343d46")
        ax.set_yticks(range(len(selected)), [short(r) for r in selected])
        ax.invert_yaxis(); ax.set_xlim(*lim); ax.set_title(title, loc="left", fontsize=13, pad=15)
        ax.set_xlabel("Balanced accuracy (%)")
        ax.grid(axis="x", color="#e0e4e8", lw=.7); ax.set_axisbelow(True)
        ax.tick_params(axis="y", length=0)
    fig.subplots_adjust(left=.20, right=.94, top=.87, bottom=.19)
    legend = [Line2D([0],[0],marker="o",color=c,lw=0,label=k.replace("Typed classifier","Decision model")) for k,c in COLORS.items() if k != "Task-specific baseline"]
    fig.legend(handles=legend,loc="lower center",ncol=4,frameon=False,fontsize=11)
    fig.savefig(ROOT/"figures/balanced-leaderboard.pdf", bbox_inches="tight")
    plt.close(fig)
    # Directly show why the metric determines different error burdens.
    fig, axes = plt.subplots(1, 2, figsize=(8.7, 3.3))
    for ax, metric, values, title in [
        (axes[0], "false_blocks", [134,297], "Non-hate posts falsely blocked"),
        (axes[1], "missed_violations", [238,124], "Hate posts missed")]:
        assert values[1] == all_rows["hatexplain"]["jev"]["metrics"][metric]
        bars=ax.bar(["Accuracy-selected", "Balance-selected"], values, color=["#8c99a5","#156f83"],width=.55)
        ax.bar_label(bars, padding=4, fontsize=11); ax.set_title(title,fontsize=11,pad=12)
        ax.set_ylim(0,350); ax.grid(axis="y",color="#e5e8eb",lw=.7); ax.set_axisbelow(True)
        ax.spines['bottom'].set_visible(False); ax.tick_params(axis="x",length=0)
    fig.tight_layout(w_pad=3)
    fig.savefig(ROOT/"figures/jev-objective-errors.pdf",bbox_inches="tight")
    plt.close(fig)
    (ROOT/"generated/leaderboard-asset-checks.json").write_text(json.dumps({"status":"passed", "entries_per_task":20,"tables":4,"decision_policy_rows":6,"source_manifest":"leaderboard-evidence/manifest.json","no_new_inference":True},indent=2)+"\n")
    print("Generated four full leaderboard tables, six policy contrasts, choices, and two figures.")

if __name__ == "__main__":
    main()
