"""Audit the paper's new empirical claims and preservation of frozen evidence.

This verifies document evidence; it does not call models or redo model selection.
The optional --evidence-root additionally checks the complete archived runs.
"""
from pathlib import Path
import argparse
import hashlib
import json
import math
import re

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'generated/leaderboard-evidence'

def read(path):
    return json.loads(path.read_text())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--evidence-root', type=Path)
    args=parser.parse_args()
    for name,record in read(DATA/'manifest.json').items():
        assert sha(DATA/name)==record['sha256'], name
        if args.evidence_root:
            assert sha(args.evidence_root/record['source'])==record['sha256']
    unchanged=None
    if args.evidence_root:
        frozen=read(ROOT/'generated/experiments-before-v0.6.json')
        for path,digest in frozen.items():
            assert sha(args.evidence_root/path)==digest, path
        unchanged=len(frozen)
    board=read(DATA/'results.json')['datasets']
    contrasts=read(DATA/'policy-contrasts.json')
    jev=read(DATA/'jev-results.json')
    ledger={}
    rows={ds:{r['group']:r for r in value['profiles']['balanced']['rows']} for ds,value in board.items()}
    n_checked=0
    for ds,value in board.items():
        assert len(rows[ds])==20
        assert value['n']=={'wildguard':1699,'hatexplain':1924}[ds]
        assert value['positives']=={'wildguard':754,'hatexplain':594}[ds]
        for profile,results in value['profiles'].items():
            for r in results['rows']:
                m=r['metrics'];c=m['confusion']
                assert sum(c.values())==value['n']
                ba=.5*(c['tp']/value['positives']+c['tn']/value['negatives'])
                assert math.isclose(m['balanced_accuracy'],ba,abs_tol=1e-12)
                assert math.isclose(m['accuracy'],(c['tp']+c['tn'])/value['n'],abs_tol=1e-12)
                assert m['unresolved']==c['error_allow']+c['error_block']
                assert (m['mcc'] is None)==bool(m['unresolved'])
                n_checked+=1
        ledger[ds]={'n':value['n'],'balanced_entries':len(rows[ds]),'balanced':{g:{k:r['metrics'][k] for k in ['balanced_accuracy','accuracy','macro_f1','mcc','false_blocks','missed_violations','unresolved']} for g,r in rows[ds].items()},'requirements':{p:{'eligible':len(value['profiles'][p]['rows']),'met':sum(bool(r['test_requirement_met']) for r in value['profiles'][p]['rows'])} for p in ['false_block_limit','catch_target']}}
    assert ledger['wildguard']['requirements']=={'false_block_limit':{'eligible':19,'met':0},'catch_target':{'eligible':20,'met':0}}
    assert ledger['hatexplain']['requirements']=={'false_block_limit':{'eligible':20,'met':17},'catch_target':{'eligible':20,'met':2}}
    assert sum(read(DATA/'coverage.json')['candidate_counts'].values())==209
    # The figure's historical operating point must come from the original Jev run.
    old=jev['datasets']['hatexplain']['test']['selected/calibrated']
    if 'metrics' in old:
        old=old['metrics']
    assert old['false_blocks']==134 and old['missed_violations']==238
    new=rows['hatexplain']['jev']['metrics']
    assert (new['false_blocks'],new['missed_violations'])==(297,124)
    ledger['jev_objective_contrast']={'original':old,'balanced':new,'extra_false_blocks':163,'fewer_misses':114}
    ledger['decision_policy_contrasts']={}
    for model in ['kev','clef']:
        for policy in ['brief','detailed','examples']:
            c=contrasts[model+'/hatexplain'][policy]
            ledger['decision_policy_contrasts'][model+'/'+policy]={k:c[k] for k in ['native','tuned','validation_selected_threshold','native_vs_brief','tuned_vs_brief']}
    c=contrasts['clef/hatexplain']['examples']
    assert (c['native']['false_blocks'],c['native']['missed_violations'])==(819,39)
    assert (c['tuned']['false_blocks'],c['tuned']['missed_violations'])==(295,166)
    # New main-body percentages must appear in the actual new evidence (rounded).
    allowed={'5','90'}
    def walk(value,key=''):
        if isinstance(value,dict):
            for k,v in value.items():walk(v,k)
        elif isinstance(value,list):
            for v in value:walk(v,key)
        elif isinstance(value,(int,float)) and not isinstance(value,bool) and 0<=value<=1:
            allowed.update(f'{100*value:.{n}f}' for n in [0,1,2])
    for obj in [board,contrasts,jev]:walk(obj)
    new_text='\n'.join((ROOT/'sections'/f).read_text() for f in ['decision-models.tex','leaderboard.tex'])
    displayed=set(re.findall(r'(\d+(?:\.\d+)?)\\%',new_text))
    assert displayed<=allowed, displayed-allowed
    main=(ROOT/'main.tex').read_text()
    body='\n'.join((ROOT/'sections'/f).read_text() for f in ['introduction.tex','methods.tex','results.tex','decision-models.tex','leaderboard.tex','discussion.tex'])
    abstract=main.split('\\begin{abstract}')[1].split('\\end{abstract}')[0]
    assert 'frontier' not in (abstract+body).lower()
    assert 'Section~\\ref{sec:leaderboard}' in body
    assert 'not a wording-only' in body and 'unequal' in (abstract+body).lower()
    assert 'no open weights were identified' in body
    cites=set()
    for f in [ROOT/'main.tex',*(ROOT/'sections').glob('*.tex')]:
        for group in re.findall(r'\\cite\w*\{([^}]+)\}',f.read_text()):cites.update(group.split(','))
    bib=set(re.findall(r'@\w+\{([^,]+),',(ROOT/'references.bib').read_text()))
    assert cites<=bib,cites-bib
    log=(ROOT/'main.log').read_text()
    assert not re.search(r'Overfull|undefined|LaTeX Warning',log), 'Inspect compilation log'
    report={'status':'passed','version':'0.6','date':'2026-10-29','metric_rows_recomputed_from_confusion':n_checked,'experiment_files_unchanged':unchanged,'new_displayed_percentage_values_checked':sorted(displayed),'citation_keys_verified':len(cites),'frontier_only_in_appendix':True,'no_new_inference':True,'claims':ledger}
    (ROOT/'generated/revision-v0.6-claim-checks.json').write_text(json.dumps(report,indent=2)+'\n')
    print(f'Passed: {n_checked} metric rows, {len(cites)} citations, {unchanged} unchanged experiment files.')

if __name__=='__main__':main()
