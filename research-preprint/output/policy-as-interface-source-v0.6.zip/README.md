# Policy as an Interface

**Authoring and Evaluating Moderation with Language and Decision Models**  
Harsh Singhal · author review **v0.6** · 29 October 2026

The central message is that policy authoring is deeply coupled with AI engineering. A moderation team needs an agreed policy and representative evaluation cases, then must test the policy, native model adapter, and decision rule together. A new model is a candidate for that process, not an automatic replacement.

## Read and edit

- [Current PDF — 38 pages](output/pdf/policy-as-interface-review-v0.6.pdf).
- [Editable LaTeX project](main.tex), with prose in `sections/`.
- [Portable source ZIP](output/policy-as-interface-arxiv-source-v0.6.zip).
- [Revision record](REVISION-v0.6.md).
- [Numerical evidence audit](generated/revision-v0.6-claim-checks.json).

This is an exploratory author-review draft. It has not been submitted to arXiv or peer reviewed, and has no arXiv identifier.

## A short reading route

For the new evidence, start with **Section 6** (decision models, pp. 11–12), **Section 7** (balanced leaderboard and error tradeoffs, pp. 12–15), and **Section 8** (implications for moderation teams, pp. 15–18). The introduction explains the policy-authoring motivation. Sections 3–5 retain the earlier wording, model comparison, transfer, structure, and ensemble experiments and their original selection objectives.

Appendix G gives Jev/Kev/Clef interfaces, source pins, policy candidates, and cutoff choices. Appendix H gives metric definitions, all 20 leaderboard entries per task, false blocks, missed violations, unresolved outputs, and operating-target attainment. The frontier API pilot remains only in Appendix I.

## What changed

The revision adds the Jev study, the retrospective balanced leaderboard, and the open decision-model extension for Kev and Clef. The complete leaderboard has 20 individual-model or ensemble entries per benchmark and 209 eligible archived candidate records. Those are not 209 distinct models. Historical accuracy-oriented results remain labeled separately; the new common selection uses validation, not each model's highest test score.

New figures show cross-family balanced performance with uncertainty and the error tradeoff between two Jev selection objectives. A new policy table distinguishes native decisions from policy-plus-cutoff effects. The discussion separates observed accuracy from deployment control: Jev was API-only in reviewed sources; Kev and Clef were self-hosted through their native heads. No matched latency, cost, privacy, or architectural-superiority conclusion is drawn.

The paper proposes shared responsibilities for policy/Trust and Safety, engineering, evaluation, product/operations, and GRC/legal. This organizational workflow was not tested with professional teams. English binary benchmarks do not validate review routing, enterprise access control, images, or multilingual moderation. No additional underlying-model fine-tuning was performed, but the released models were trained by their creators and learned calibrators/combiners use labels.

## Build and verify

Compile the saved project offline with a conventional TeX installation or the Codex desktop LaTeX editor. For Tectonic:

```sh
tectonic --keep-logs --keep-intermediates main.tex
```

The source package includes the figures, tables, bibliography, policy files, and prompt-free evidence summaries needed for compilation. No GPU or provider token is required. Python 3 with Matplotlib can regenerate the new figures and tables from the bundled evidence:

```sh
python build_leaderboard_assets.py
python verify_v06.py
```

When a full current experiment checkout is available, add `--evidence-root /path/to/safeguard-eval` to refresh the asset inputs or check all 3,235 archived experiment-file hashes. This revision checks 119 configuration/profile metric rows against their confusion counts, verifies 33 citation keys, and preserves the existing experiment archives. Historical builders and `verify_revision.py` document earlier versions and have their original full-repository requirements; use `verify_v06.py` for the current evidence audit.

Full inference reproduction uses the corresponding `published_runs/` bundles and authorized source data. Redacted demonstration text in public evidence is explicitly marked and is not the actual inference prompt. The paper source archive is not a substitute for the complete run archives.

## Version preservation

Earlier PDFs and source ZIPs remain under `output/`. The pre-edit v0.5 working files are preserved under `archive/v0.5/`. The v0.6 evidence map distinguishes the earlier public snapshot from the later companion checkout. The paper was edited in place, with no new inference or paid service. Magazine, media, and installed skill versions were not revised as part of this paper update.
