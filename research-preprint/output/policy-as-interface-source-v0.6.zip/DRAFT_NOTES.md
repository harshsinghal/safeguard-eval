# Draft preparation record

2026-10-25: Prepared a review manuscript from repository snapshot `b403b1fccbfca520d6febe9260d3802ae06a22e4`. No new model inference, GPU rental, paid API use, or arXiv submission.

Read the completed specialist and Qwen methods, claim maps, selection ledgers, runtime documentation, and results, plus the frontier pilot's records. Inspected the actual confusion matrices: the frontier sample contains 29 ALLOW and three BLOCK labels. Two unique harmful-labeled prompts account for four Opus content-filter outcomes across settings. The rate limit and two Kimi invalid-format outcomes concern benign-labeled cases.

Verified primary references through official model/dataset cards, the WildGuard/CoPE/Shieldstral papers, prompt-optimization papers, official OpenAI documentation, and OpenRouter model/routing/reasoning pages. Checked arXiv's LaTeX submission documentation for source packaging. Undated living pages are marked n.d. with an explicit access date; no paper is invented for a checkpoint that has only a model card.

Generated empirical tables and figures from archived analysis JSON. Verified all 409 Study A, 414 Study B, and 1,072 frontier archive checksum entries. Independently checked every 1,699-row test configuration's accuracy, harmful F1, output-error count, and population total from its confusion matrix (12 specialist/baseline configurations and 14 Qwen configurations). Archived predictions and freezes were not changed.

The draft separates three ideas that should not be conflated: benchmark agreement, fidelity to an arbitrary supplied policy, and operator control over deployment. Self-hosting is presented as an architectural control option, not an empirically established cure for refusals or an accuracy advantage. The word “often” is not supported by the current API pilot.

First compilation exposed a LaTeX table-input expansion issue; the source now uses an expandable table-input command. A later layout pass added safe URL line wrapping and scoped appendix table typography. Standard article format, single column, 11-point text, five vector figures, and 24 bibliography entries support readable review and portable source compilation.

Human review remains needed for authorship/affiliation, motivation, wording, and the priorities for future experiments. Manuscript publication is deliberately left to the author after review. The draft makes observations but leaves broader scientific conclusions open.

Final checks: 21 pages, five figures, 24 references, zero unresolved references or LaTeX warnings. All rendered pages reviewed; diagram and chart label collisions repaired. The desktop editor compiler succeeded. The 22-file source ZIP compiled in an isolated temporary directory and produced identical extracted text on all 21 pages. Exported PDF and source ZIP hashes are in output/MANIFEST.json.


## Clarity rewrite — v0.2

2026-10-25: Applied Clarity v0.2.1 in rewrite mode from `addyosmani/clarity` at revision `e27ceeff60368cf6966b4ea00a5b9b36418ee9a0`. Read `SKILL.md`, `references/edit.md`, `references/medium.md`, and `references/longform.md`. The fetched instructions and provenance are retained locally under ignored `tmp/clarity/`; the skill was not installed globally.

The main issue was development and density, rather than missing evidence. The rewrite establishes one through-line: changing policy text changes decisions, and we need selection and threshold controls to interpret any gain. It explains fitting, validation, audit, and test before implementation details; gives concrete policy edits; and defines “selected” as the validation winner among five candidates. It keeps the original motivating image-platform example explicitly outside the measured task.

Protected claims include the 1,699-row test population and 26 null-label exclusions; fixed weights; the bounded five-candidate search; train/test annotation differences; prior exposure and adaptive selection; unchanged accuracy/F1/intervals; the threshold explanation; unresolved Safeguard errors; and the absence of a new matched fine-tuning experiment. All generated numerical and initial-policy TeX fragments remain byte-identical to v0.1. All 24 citation keys and bibliography targets are retained.

Removed the frontier pilot from the abstract, main research questions, methods follow-up, results introduction, governance section, main limitations, future work, and body cost statement. Appendix F now contains its counts, settings, cost, provider-control qualification, and remaining work. The eight conditions still contain only 32 unique fitting requests, with three harmful labels; two unique filtered prompts generate four filter outcomes. No full frontier tuning/test is implied. The body now reports only the $6.34 cost of Studies A and B. The two old API/deployment illustrations remain unused assets; the revised paper uses three figures.

No experimental policies, predictions, model settings, or evidence archives were edited. No new paid inference or public submission occurred. The v0.1 PDF, source ZIP, manifest, and validation record are preserved. This editorial change does not upgrade exploratory evidence into a confirmatory study.

Final v0.2 validation: 18 pages, three figures, 24 references, and no LaTeX warnings or unresolved references. Reviewed all rendered pages and repaired a heading separated from its table. The desktop compiler succeeded. The 45-file source ZIP compiled independently without warnings and reproduced identical extracted text on all 18 pages. The seven generated TeX fragments, bibliography, and three retained figure PDFs are byte-identical to v0.1. The previous PDF and ZIP still match their original hashes. The full rewritten prose received one editorial self-review for scope, qualification, numerical fidelity, and paragraph flow.


## Policy-authoring theme — v0.3

2026-10-25: Revised the paper in response to the author’s feedback about its core audience and purpose. The author supplied the motivation: policy development and application require shared work between GRC, Trust and Safety, and engineering; policy authoring should receive the same attention as model selection. The model supplied the rewritten prose and a proposed workflow diagram, grounded in that direction and the existing experiment records.

Changed the subtitle to “Policy Authoring and Model Choice in LLM Moderation.” Replaced the iconography introduction with the respective policy and engineering responsibilities. Removed the iconography example from the limitations and future work as well. Reframed the methods around evaluating a policy draft as a task specification, and the results around how authoring and model choices change outcomes. Added explanations of score cutoffs and F1 for readers outside ML research.

Section 5 now develops a shared review process: distinguish changes in meaning from clearer expression, examine both improvements and regressions, assess policy and cutoff together, and version the policy/model/settings with their evaluation evidence. The diagram is explicitly conceptual and proposed, not an empirical claim about organizations. It is generated by build_workflow_figure.py and included in the full build_assets.py workflow.

Scientific boundaries retained: the study does not show equal numerical contributions from policy and model choice, does not compare newly run fine-tuning, and did not involve recruited professional policy authors. Added a corresponding limitation and proposed a practitioner authoring study. Existing calibration controls, negative results, uncertainty, prior exposure, adaptive-search limits, and the distinction between benchmark labels and policy intent remain explicit. The unchanged frontier pilot remains only in Appendix F.

All seven generated numerical/policy TeX fragments, all 21 archived policy JSON copies, and references.bib were compared with the v0.2 source ZIP and remain byte-identical. No new model inference, paid resources, or submission was used. Prior PDF/source exports remain available. The rewrite follows the previously loaded Clarity guidance and received an editorial check for claim strength and audience fit.

Final v0.3 validation: 20 pages, four figures, 24 references. Both the local and desktop compilers succeeded; local and independent source-package compilations emitted no warnings. Every page was visually inspected, with full-size review of the opening and the proposed workflow diagram. The 47-file source ZIP reproduced identical extracted text on every page. All prior PDF/ZIP hashes remain intact. No measured numerical or policy artifacts changed.


## Policy authoring as classifier development — v0.4

2026-10-25: Rewrote the paper around the author's requested responsibility: policy development teams should own authored policy text as developers own code, with the selected model acting as a learned interpreter. Read the pinned Clarity rewrite/long-form/academic guidance and used the PDF workflow. The analogy is explicitly limited: natural-language rules lack formal semantics, and the model may behave inconsistently or rely on its training.

The current evidence snapshot is `0b873f611fd6c90cd77c1d0423044f64e5a933ec`. Added the completed source-isolated transfer study, previously absent from the manuscript, as Study C. Reorganized the results so each study and the cutoff control explain design, measured outcomes, and implications for policy authors and engineers. Preserved the unchanged-policy winners, negative transfers, the earlier 91.29% Qwen 27B configuration, the absence of a successful new 27B-specific policy, and variation in repeated initial-policy runs. The main three-study cost is $8.66; this is not the cumulative project bill or a production cost estimate.

The new transfer matrix shows every recipient/policy test combination and outlines validation selections. Additional tables report source selection, recipient selection, and metrics beyond accuracy. All 20 fresh drafts are added to the existing 21 policies; their bytes and hashes match the archived evidence. The seven earlier numerical/policy TeX fragments and the frontier appendix remain byte-identical to v0.3. Frontier comparisons remain confined to Appendix F.

The shared workflow assigns policy teams responsibility for intended scope, exceptions, precedence, reviewable changes, and acceptable error tradeoffs. Engineers own the tested model, adapter, cutoff, and runtime. Both inspect behavioral regressions. The paper presents this as a recommendation supported by complementary failure modes, not a measured benefit of professional collaboration. Enterprise GRC is a future application, with no inference that a prompt classifier replaces access or disclosure controls.

Evidence verification rechecked 409 Study A, 414 Study B, 476 Study C, and 1,072 appendix-pilot checksum entries. Accuracy, harmful F1, error counts, and population totals were recomputed from the confusion matrices for 12 Study A, 14 Study B, and all 20 Study C test configurations, plus Study C's 20 audit configurations. The policy corpus contains 41 distinct unchanged source texts. A method review caught and corrected a word-count distinction: A/B tie-break counts include all JSON values; C selection counts four substantive fields, while its hard length check still covers all JSON values.

No new model inference, spending, edit to experimental evidence, or public manuscript publication was performed. Earlier PDF and source-package exports are preserved. Compilation and visual/package validation are recorded below after completion.

Final v0.4 checks: 24 pages, five figures, 24 references, 41 policy texts, and 73 files in the portable source ZIP. Local and desktop editor compilers succeeded. The final local build and isolated source-package build emitted no warnings; the portable build reproduces identical extracted text on every page. Every page was visually reviewed; after the final edit, the three changed pages were rendered and reviewed again, with all other rendered page hashes unchanged. The editorial self-review corrected the cutoff interpretation to avoid implying a causal explanation and grouped Study C's appendix heading with its own tables. No missing citations, replacement characters, or unresolved references remain. Earlier v0.1–v0.3 PDF and source hashes match their original manifests. Export hashes and detailed checks are in output/MANIFEST-v0.4.json and output/validation-v0.4.json.

## Integrated research narrative — v0.5

2026-10-28: Rewrote the three article forms together at the user's request. The research paper now includes six studies: specialist wording, instruction-model comparison, fresh transfer, HateXplain structure/omission/transfer, score ensembles, and the log-odds extension. The main narrative explains why each question follows the preceding result. Detailed model tables and controls are in appendices, with the frontier pilot still confined to an appendix (now G).

The claim is competitive classification without additional language-model fine-tuning by the deploying team. It remains distinct from no training, no labels, lower total effort, or superiority to a matched fine-tuning project. Policy-editing, calibration, and combination gains are separated. Negative transfers, rejected wording, specialist-only ensemble failure, an earlier higher equal-average score, and error tradeoffs remain visible.

Inspected the media DOCX before rebuilding: it exactly matched its JSON source, with no comments or tracked changes. Archived the preprint v0.4, magazine v0.3 and media v0.2 working sources and outputs before any rewrite. The evidence check covers 3,030 unchanged experiment files. Companion packages now include prompt-free extension records with source hashes. No inference, paid service or publication was performed.

Clarity's pinned rewrite, long-form and academic guidance informed one substantive editorial review. Later repairs concerned claim precision and layout, including a long hash, a narrow table label, a split short quotation and reference pagination. The original IEEE class and styles remain unchanged.

Final validation: all 25 paper pages, six magazine pages and four rendered Word
pages were inspected. Both LaTeX projects compile in the desktop editor and from
isolated source archives; the independently compiled PDFs have identical page
text and geometry to the review exports. The preprint compiles without warnings.
The magazine retains the official template's box warnings, checked against the
rendered pages. The media source contains 1,426 body words and exactly matches
the editable DOCX, including six source links. Final records are in
`output/validation-v0.5.json` and the companions' `generated/document-checks.json`.
The review panel accepted queued open requests for all three documents. Source
archives and review PDFs are versioned; no earlier export was overwritten.


## v0.6 — 29 October 2026

Integrated Jev, Kev, Clef, and the 20-entry-per-task balanced leaderboard. Historical accuracy-oriented selections remain distinct from the retrospective common validation objectives. Added full balanced metrics and error tables, policy/cutoff contrasts, uncertainty, operating-target failures, and stakeholder implications. Reframed model choice around approved policy meaning, representative labeled evaluations, native adapters, and release decisions. API versus open-weight operation is distinguished from accuracy; no unverified Jev architecture or matched serving-efficiency claim. All existing run evidence stays frozen. See REVISION-v0.6.md and generated/revision-v0.6-claim-checks.json.
